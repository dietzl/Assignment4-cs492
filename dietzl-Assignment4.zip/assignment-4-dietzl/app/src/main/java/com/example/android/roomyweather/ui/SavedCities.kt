package com.example.android.roomyweather.ui

import com.example.android.roomyweather.data.ForecastCityEntry
import com.example.android.roomyweather.data.ForecastPeriodDao

class SavedCities (
    private val dao: ForecastPeriodDao
) {
    suspend fun insertCity(city: ForecastCityEntry) = dao.insert(city)
    fun getAllCities() = dao.getAllCities()
}