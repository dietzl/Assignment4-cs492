package com.example.android.roomyweather.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.android.roomyweather.data.AppDatabase
import com.example.android.roomyweather.data.ForecastCityEntry
import kotlinx.coroutines.launch

class SavedCitiesViewModel(application: Application) : AndroidViewModel(application){
    private val cities = SavedCities(
        AppDatabase.getInstance(application).forecastDAO()
    )

    val savedCities = cities.getAllCities().asLiveData()

    fun addCity(city: ForecastCityEntry) {
        viewModelScope.launch {
            cities.insertCity(city)
        }
    }

    fun getAllCities() {
        viewModelScope.launch {
            cities.getAllCities()
        }
    }
}