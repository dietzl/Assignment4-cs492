package com.example.android.roomyweather.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.android.roomyweather.R
import com.example.android.roomyweather.data.ForecastCityEntry

class DrawerAdapter(private val onClick: (ForecastCityEntry) -> Unit)
    : RecyclerView.Adapter<DrawerAdapter.ViewHolder>(){
    var forecastList: List<ForecastCityEntry> = listOf()
    fun updateCityList(newCityList: List<ForecastCityEntry>?) {
        forecastList = newCityList ?: listOf()
        notifyDataSetChanged()
    }

    override fun getItemCount() = this.forecastList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrawerAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.cities_list_item, parent, false)
        return ViewHolder(view, onClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(forecastList[position])
    }

    class ViewHolder(itemView: View, val onClick: (ForecastCityEntry) -> Unit): RecyclerView.ViewHolder(itemView) {
        private val cityNameTV: TextView = itemView.findViewById(R.id.tv_city)
        private var currentForecastCityEntry: ForecastCityEntry? = null
        init {
            itemView.setOnClickListener {
                currentForecastCityEntry?.let(onClick)
            }
        }
        fun bind(cityEntry: ForecastCityEntry){
            currentForecastCityEntry = cityEntry
            cityNameTV.text = cityEntry.city_name
        }
    }


}