package com.example.android.roomyweather.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ForecastPeriodDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(forecast: ForecastCityEntry)

    @Query("SELECT * FROM ForecastCityEntry")
    fun getAllCities(): Flow<List<ForecastCityEntry>>
}