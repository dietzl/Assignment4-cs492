package com.example.android.roomyweather.ui

import android.app.Application
import androidx.lifecycle.*
import com.example.android.roomyweather.data.*


class ForecastResultsViewModel(application: Application) : AndroidViewModel(application){

    private val _cities = MutableLiveData<List<ForecastCityEntry>>(null)
    var cities: LiveData<List<ForecastCityEntry>> = _cities

    private val citiesRepo = SavedCities(AppDatabase.getInstance(application).forecastDAO())

    fun loadSavedCities() {
        cities = citiesRepo.getAllCities().asLiveData()
    }

}