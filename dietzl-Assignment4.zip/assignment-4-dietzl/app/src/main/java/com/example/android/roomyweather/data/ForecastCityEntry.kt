package com.example.android.roomyweather.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity
data class ForecastCityEntry(
    @PrimaryKey var city_name: String,
    var timestamp: Long
): Serializable
